import React from 'react';
import { Link } from 'react-router-dom';
import { Video, PlayCircle, Sparkles, Clock } from 'lucide-react';

const features = [
  {
    icon: <Sparkles className="w-6 h-6 text-indigo-600" />,
    title: 'AI-Powered Creation',
    description: 'Turn text prompts into stunning 30-second videos using advanced AI technology.'
  },
  {
    icon: <Clock className="w-6 h-6 text-indigo-600" />,
    title: 'Quick Generation',
    description: 'Create professional-quality videos in seconds, not hours.'
  },
  {
    icon: <PlayCircle className="w-6 h-6 text-indigo-600" />,
    title: 'Multiple Styles',
    description: 'Choose from various video styles including cinematic, animation, minimal, and retro.'
  }
];

const exampleVideos = [
  {
    id: 1,
    title: 'Mountain Sunrise',
    thumbnail: 'https://images.pexels.com/photos/1054289/pexels-photo-1054289.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=650&w=940',
    prompt: 'A beautiful timelapse of a mountain sunrise with clouds rolling over peaks'
  },
  {
    id: 2,
    title: 'Ocean Waves',
    thumbnail: 'https://images.pexels.com/photos/1295138/pexels-photo-1295138.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=650&w=940',
    prompt: 'Calming blue ocean waves gently crashing on a sandy beach at sunset'
  },
  {
    id: 3,
    title: 'City Nightlife',
    thumbnail: 'https://images.pexels.com/photos/1538177/pexels-photo-1538177.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=650&w=940',
    prompt: 'Bustling city nightlife with neon lights and people walking through busy streets'
  }
];

const HomePage: React.FC = () => {
  return (
    <div className="space-y-16">
      {/* Hero Section */}
      <section className="relative overflow-hidden rounded-3xl bg-gradient-to-br from-indigo-600 to-purple-700 text-white">
        <div className="absolute inset-0 bg-black/20"></div>
        <div className="relative z-10 px-6 py-16 md:py-24 lg:py-32 max-w-4xl mx-auto text-center">
          <h1 className="text-4xl md:text-5xl lg:text-6xl font-bold leading-tight">
            Create Stunning 30-Second Videos with AI
          </h1>
          <p className="mt-6 text-lg md:text-xl text-white/90 max-w-2xl mx-auto">
            Transform your ideas into beautiful, professional videos in seconds. Just type a prompt and let our AI do the rest.
          </p>
          <div className="mt-10 flex flex-col sm:flex-row gap-4 justify-center">
            <Link
              to="/create"
              className="px-8 py-4 rounded-lg bg-white text-indigo-700 font-medium text-lg transition-all hover:bg-gray-100 shadow-lg hover:shadow-xl flex items-center justify-center space-x-2"
            >
              <Video className="w-5 h-5" />
              <span>Create Video</span>
            </Link>
            <a
              href="#examples"
              className="px-8 py-4 rounded-lg bg-indigo-500/20 backdrop-blur-sm text-white font-medium text-lg border border-white/20 transition-all hover:bg-indigo-500/30 flex items-center justify-center space-x-2"
            >
              <PlayCircle className="w-5 h-5" />
              <span>See Examples</span>
            </a>
          </div>
        </div>
        
        {/* Decorative elements */}
        <div className="absolute -bottom-6 left-0 right-0 h-12 bg-gradient-to-t from-white/5 to-transparent backdrop-blur-sm"></div>
      </section>
      
      {/* Features Section */}
      <section className="py-8">
        <div className="max-w-6xl mx-auto">
          <h2 className="text-3xl font-bold text-gray-900 dark:text-white text-center mb-12">
            Why Choose ShortCut?
          </h2>
          <div className="grid md:grid-cols-3 gap-8">
            {features.map((feature, index) => (
              <div 
                key={index} 
                className="p-6 bg-white dark:bg-gray-800 rounded-2xl shadow-md hover:shadow-xl transition-shadow border border-gray-100 dark:border-gray-700"
              >
                <div className="w-12 h-12 rounded-full bg-indigo-100 dark:bg-indigo-900/30 flex items-center justify-center mb-4">
                  {feature.icon}
                </div>
                <h3 className="text-xl font-semibold text-gray-900 dark:text-white mb-2">
                  {feature.title}
                </h3>
                <p className="text-gray-600 dark:text-gray-300">
                  {feature.description}
                </p>
              </div>
            ))}
          </div>
        </div>
      </section>
      
      {/* Example Videos Section */}
      <section id="examples" className="py-8">
        <div className="max-w-6xl mx-auto">
          <h2 className="text-3xl font-bold text-gray-900 dark:text-white text-center mb-4">
            Example Videos
          </h2>
          <p className="text-gray-600 dark:text-gray-300 text-center max-w-2xl mx-auto mb-12">
            Check out these sample videos created with our AI video generator. You can create similar videos with just a text prompt.
          </p>
          
          <div className="grid md:grid-cols-3 gap-6">
            {exampleVideos.map((video) => (
              <div 
                key={video.id} 
                className="group bg-white dark:bg-gray-800 rounded-lg overflow-hidden shadow-md hover:shadow-xl transition-all duration-300"
              >
                <div className="relative aspect-video">
                  <img 
                    src={video.thumbnail} 
                    alt={video.title} 
                    className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-105"
                  />
                  <div className="absolute inset-0 bg-black/40 opacity-0 group-hover:opacity-100 transition-opacity duration-300 flex items-center justify-center">
                    <PlayCircle className="w-16 h-16 text-white" />
                  </div>
                </div>
                <div className="p-4">
                  <h3 className="font-medium text-gray-900 dark:text-white">{video.title}</h3>
                  <p className="text-sm text-gray-500 dark:text-gray-400 mt-1 line-clamp-2">
                    Prompt: "{video.prompt}"
                  </p>
                </div>
              </div>
            ))}
          </div>
          
          <div className="mt-10 text-center">
            <Link
              to="/create"
              className="inline-flex items-center space-x-2 px-6 py-3 rounded-lg bg-indigo-600 text-white font-medium hover:bg-indigo-700 transition-colors shadow-md hover:shadow-lg"
            >
              <Sparkles className="w-5 h-5" />
              <span>Create Your Own Video</span>
            </Link>
          </div>
        </div>
      </section>
    </div>
  );
};

export default HomePage;