import React from 'react';
import PromptForm from '../components/PromptForm';
import VideoPreview from '../components/VideoPreview';
import { useVideo } from '../context/VideoContext';

const CreatePage: React.FC = () => {
  const { currentVideo, isGenerating } = useVideo();

  return (
    <div className="max-w-6xl mx-auto">
      <div className="text-center mb-8">
        <h1 className="text-3xl font-bold text-gray-900 dark:text-white">Create Your Video</h1>
        <p className="mt-2 text-gray-600 dark:text-gray-300 max-w-2xl mx-auto">
          Describe what you want to see in your video, select style options, and our AI will generate a 30-second video for you.
        </p>
      </div>
      
      <div className="grid md:grid-cols-2 gap-8">
        <div className="order-2 md:order-1">
          <PromptForm />
          
          <div className="mt-8">
            <h3 className="text-lg font-medium text-gray-900 dark:text-white mb-4">Tips for Great Results</h3>
            <ul className="space-y-2 text-gray-600 dark:text-gray-300">
              <li className="flex items-start">
                <span className="text-indigo-600 dark:text-indigo-400 font-medium mr-2">•</span>
                <span>Be specific about what you want to see in the video</span>
              </li>
              <li className="flex items-start">
                <span className="text-indigo-600 dark:text-indigo-400 font-medium mr-2">•</span>
                <span>Include details about lighting, mood, and camera movements</span>
              </li>
              <li className="flex items-start">
                <span className="text-indigo-600 dark:text-indigo-400 font-medium mr-2">•</span>
                <span>Mention any specific objects or scenes you want featured</span>
              </li>
              <li className="flex items-start">
                <span className="text-indigo-600 dark:text-indigo-400 font-medium mr-2">•</span>
                <span>Choose a style that complements your content</span>
              </li>
            </ul>
          </div>
        </div>
        
        <div className="order-1 md:order-2">
          <h2 className="text-xl font-medium text-gray-900 dark:text-white mb-4">Video Preview</h2>
          <VideoPreview 
            videoUrl={currentVideo?.url || null}
            thumbnail={currentVideo?.thumbnail || null}
            isLoading={isGenerating}
            title={currentVideo?.title || 'New Video'}
          />
          
          {currentVideo && !isGenerating && (
            <div className="mt-4 p-4 bg-white dark:bg-gray-800 rounded-lg border border-gray-200 dark:border-gray-700">
              <h3 className="font-medium text-gray-900 dark:text-white">{currentVideo.title}</h3>
              <p className="mt-1 text-sm text-gray-600 dark:text-gray-300">
                {currentVideo.prompt}
              </p>
              <div className="flex flex-wrap gap-2 mt-3">
                <span className="px-2 py-1 text-xs rounded-full bg-indigo-100 dark:bg-indigo-900/30 text-indigo-700 dark:text-indigo-400">
                  {currentVideo.style}
                </span>
                {currentVideo.music !== 'none' && (
                  <span className="px-2 py-1 text-xs rounded-full bg-purple-100 dark:bg-purple-900/30 text-purple-700 dark:text-purple-400">
                    {currentVideo.music}
                  </span>
                )}
                {currentVideo.voice !== 'none' && (
                  <span className="px-2 py-1 text-xs rounded-full bg-blue-100 dark:bg-blue-900/30 text-blue-700 dark:text-blue-400">
                    {currentVideo.voice}
                  </span>
                )}
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default CreatePage;