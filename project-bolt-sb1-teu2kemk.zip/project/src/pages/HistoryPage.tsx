import React, { useState } from 'react';
import { History, Search } from 'lucide-react';
import VideoCard from '../components/VideoCard';
import { useVideo } from '../context/VideoContext';

const HistoryPage: React.FC = () => {
  const { videos } = useVideo();
  const [searchTerm, setSearchTerm] = useState('');
  
  const filteredVideos = videos.filter(
    (video) => 
      video.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
      video.prompt.toLowerCase().includes(searchTerm.toLowerCase())
  );

  return (
    <div className="max-w-6xl mx-auto">
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 mb-8">
        <div>
          <h1 className="text-3xl font-bold text-gray-900 dark:text-white flex items-center">
            <History className="w-8 h-8 mr-2 text-indigo-600 dark:text-indigo-400" />
            Your Videos
          </h1>
          <p className="mt-2 text-gray-600 dark:text-gray-300">
            Access and manage your previously created videos
          </p>
        </div>
        
        <div className="w-full md:w-64">
          <div className="relative">
            <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
              <Search className="w-5 h-5 text-gray-400" />
            </div>
            <input
              type="text"
              placeholder="Search videos..."
              className="w-full pl-10 pr-4 py-2 border border-gray-300 dark:border-gray-700 rounded-lg bg-white dark:bg-gray-800 text-gray-900 dark:text-gray-100 focus:ring-2 focus:ring-indigo-500/20 dark:focus:ring-indigo-500/30 focus:border-indigo-500 transition-all"
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
            />
          </div>
        </div>
      </div>
      
      {filteredVideos.length > 0 ? (
        <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-6">
          {filteredVideos.map((video) => (
            <VideoCard key={video.id} video={video} />
          ))}
        </div>
      ) : (
        <div className="text-center py-16">
          <div className="w-16 h-16 rounded-full bg-indigo-100 dark:bg-indigo-900/30 flex items-center justify-center mx-auto">
            <History className="w-8 h-8 text-indigo-600 dark:text-indigo-400" />
          </div>
          <h3 className="mt-4 text-lg font-medium text-gray-900 dark:text-white">
            {searchTerm ? 'No videos match your search' : 'No videos yet'}
          </h3>
          <p className="mt-2 text-gray-600 dark:text-gray-300 max-w-md mx-auto">
            {searchTerm 
              ? 'Try searching with different keywords or clear your search to see all videos.'
              : 'Create your first video by going to the Create page and entering a prompt.'}
          </p>
        </div>
      )}
    </div>
  );
};

export default HistoryPage;