import React, { createContext, useContext, useState, useEffect } from 'react';
import { Video } from '../types';

// Example video placeholders
const placeholderVideos = [
  {
    id: '1',
    title: 'Mountain Landscape',
    prompt: 'A beautiful mountain landscape with snow-capped peaks and a flowing river.',
    url: 'https://player.vimeo.com/external/517090081.hd.mp4?s=90d239220d9bbf5304aaa3336b3d4e7e435eb62f&profile_id=174&oauth2_token_id=57447761',
    thumbnail: 'https://images.pexels.com/photos/1054289/pexels-photo-1054289.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=650&w=940',
    style: 'Cinematic',
    music: 'Ambient',
    voice: 'None',
    createdAt: new Date(Date.now() - 5 * 24 * 60 * 60 * 1000).toISOString()
  },
  {
    id: '2',
    title: 'Ocean Sunset',
    prompt: 'A peaceful ocean sunset with gentle waves and colorful sky.',
    url: 'https://player.vimeo.com/external/446653974.hd.mp4?s=755111e60d6771038315c9e12f090cb536538a36&profile_id=174&oauth2_token_id=57447761',
    thumbnail: 'https://images.pexels.com/photos/1295138/pexels-photo-1295138.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=650&w=940',
    style: 'Minimal',
    music: 'Upbeat',
    voice: 'Male',
    createdAt: new Date(Date.now() - 3 * 24 * 60 * 60 * 1000).toISOString()
  },
  {
    id: '3',
    title: 'City Nightlife',
    prompt: 'Bustling city nightlife with neon lights and busy streets.',
    url: 'https://player.vimeo.com/external/409475626.hd.mp4?s=afb53f71737c8d5c1155af58b550fa1da4959cd0&profile_id=174&oauth2_token_id=57447761',
    thumbnail: 'https://images.pexels.com/photos/1538177/pexels-photo-1538177.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=650&w=940',
    style: 'Retro',
    music: 'Dramatic',
    voice: 'Female',
    createdAt: new Date(Date.now() - 1 * 24 * 60 * 60 * 1000).toISOString()
  }
];

// Sample video URLs for generation
const sampleVideoUrls = [
  'https://player.vimeo.com/external/446653974.hd.mp4?s=755111e60d6771038315c9e12f090cb536538a36&profile_id=174&oauth2_token_id=57447761',
  'https://player.vimeo.com/external/517090081.hd.mp4?s=90d239220d9bbf5304aaa3336b3d4e7e435eb62f&profile_id=174&oauth2_token_id=57447761',
  'https://player.vimeo.com/external/409475626.hd.mp4?s=afb53f71737c8d5c1155af58b550fa1da4959cd0&profile_id=174&oauth2_token_id=57447761',
  'https://player.vimeo.com/external/371845807.hd.mp4?s=76b1f4554345e5ffb6a49aa990b43445c8220559&profile_id=174&oauth2_token_id=57447761',
  'https://player.vimeo.com/external/384761420.hd.mp4?s=682e8366e6c3a5ab0e9c42cd2a8b41ff46e3a2f2&profile_id=174&oauth2_token_id=57447761'
];

// Sample thumbnail URLs
const sampleThumbnailUrls = [
  'https://images.pexels.com/photos/1054289/pexels-photo-1054289.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=650&w=940',
  'https://images.pexels.com/photos/1295138/pexels-photo-1295138.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=650&w=940',
  'https://images.pexels.com/photos/1538177/pexels-photo-1538177.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=650&w=940',
  'https://images.pexels.com/photos/3680219/pexels-photo-3680219.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=650&w=940',
  'https://images.pexels.com/photos/2559941/pexels-photo-2559941.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=650&w=940'
];

interface VideoContextProps {
  videos: Video[];
  currentVideo: Video | null;
  isGenerating: boolean;
  generateVideo: (prompt: string, style: string, music: string, voice: string) => void;
  deleteVideo: (id: string) => void;
}

const VideoContext = createContext<VideoContextProps | undefined>(undefined);

export const useVideo = () => {
  const context = useContext(VideoContext);
  if (context === undefined) {
    throw new Error('useVideo must be used within a VideoProvider');
  }
  return context;
};

interface VideoProviderProps {
  children: React.ReactNode;
}

const STORAGE_KEY = 'shortcut_videos';

export const VideoProvider: React.FC<VideoProviderProps> = ({ children }) => {
  const [videos, setVideos] = useState<Video[]>([]);
  const [currentVideo, setCurrentVideo] = useState<Video | null>(null);
  const [isGenerating, setIsGenerating] = useState(false);
  
  // Load videos from localStorage on mount
  useEffect(() => {
    const storedVideos = localStorage.getItem(STORAGE_KEY);
    if (storedVideos) {
      try {
        setVideos(JSON.parse(storedVideos));
      } catch (error) {
        console.error('Failed to parse stored videos:', error);
        // Fallback to placeholder videos if parsing fails
        setVideos(placeholderVideos);
      }
    } else {
      // Use placeholder videos if no videos are stored
      setVideos(placeholderVideos);
    }
  }, []);
  
  // Save videos to localStorage whenever they change
  useEffect(() => {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(videos));
  }, [videos]);

  const generateVideo = (prompt: string, style: string, music: string, voice: string) => {
    setIsGenerating(true);
    
    // Simulate video generation with a delay
    setTimeout(() => {
      // Generate a title from the prompt
      const title = prompt.split(' ').slice(0, 5).join(' ') + '...';
      
      // Create a new video object with a random sample video and thumbnail
      const newVideo: Video = {
        id: Date.now().toString(),
        title,
        prompt,
        url: sampleVideoUrls[Math.floor(Math.random() * sampleVideoUrls.length)],
        thumbnail: sampleThumbnailUrls[Math.floor(Math.random() * sampleThumbnailUrls.length)],
        style: style.charAt(0).toUpperCase() + style.slice(1),
        music: music.charAt(0).toUpperCase() + music.slice(1),
        voice: voice.charAt(0).toUpperCase() + voice.slice(1),
        createdAt: new Date().toISOString()
      };
      
      setCurrentVideo(newVideo);
      setVideos((prevVideos) => [newVideo, ...prevVideos]);
      setIsGenerating(false);
    }, 3000); // Simulate 3 second processing time
  };
  
  const deleteVideo = (id: string) => {
    setVideos((prevVideos) => prevVideos.filter((video) => video.id !== id));
    // If the current video is being deleted, clear it
    if (currentVideo && currentVideo.id === id) {
      setCurrentVideo(null);
    }
  };
  
  return (
    <VideoContext.Provider
      value={{
        videos,
        currentVideo,
        isGenerating,
        generateVideo,
        deleteVideo
      }}
    >
      {children}
    </VideoContext.Provider>
  );
};