import React, { useState } from 'react';
import { Sparkles, Music, Mic, Palette, ChevronDown, CheckCircle2 } from 'lucide-react';
import { useVideo } from '../context/VideoContext';

const styleOptions = [
  { id: 'cinematic', name: 'Cinematic', description: 'Professional movie-like style' },
  { id: 'animation', name: 'Animation', description: 'Animated cartoon style' },
  { id: 'minimal', name: 'Minimal', description: 'Clean and simple visuals' },
  { id: 'retro', name: 'Retro', description: 'Vintage aesthetic with film grain' },
];

const musicOptions = [
  { id: 'upbeat', name: 'Upbeat', description: 'Energetic and positive' },
  { id: 'ambient', name: 'Ambient', description: 'Calm background music' },
  { id: 'dramatic', name: 'Dramatic', description: 'Intense and emotional' },
  { id: 'none', name: 'No Music', description: 'No background music' },
];

const voiceOptions = [
  { id: 'male', name: 'Male Voice', description: 'Professional male narration' },
  { id: 'female', name: 'Female Voice', description: 'Professional female narration' },
  { id: 'none', name: 'No Voice', description: 'No narration' },
];

const PromptForm: React.FC = () => {
  const { generateVideo, isGenerating } = useVideo();
  const [prompt, setPrompt] = useState('');
  const [style, setStyle] = useState(styleOptions[0].id);
  const [music, setMusic] = useState(musicOptions[0].id);
  const [voice, setVoice] = useState(voiceOptions[0].id);
  
  const [showStyleDropdown, setShowStyleDropdown] = useState(false);
  const [showMusicDropdown, setShowMusicDropdown] = useState(false);
  const [showVoiceDropdown, setShowVoiceDropdown] = useState(false);
  
  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (prompt.trim()) {
      generateVideo(prompt, style, music, voice);
    }
  };
  
  const getOptionById = (options: typeof styleOptions, id: string) => {
    return options.find(option => option.id === id) || options[0];
  };

  return (
    <form onSubmit={handleSubmit} className="w-full space-y-6">
      <div className="space-y-2">
        <label htmlFor="prompt" className="block text-sm font-medium text-gray-700 dark:text-gray-300">
          Video Prompt
        </label>
        <textarea
          id="prompt"
          rows={4}
          placeholder="Describe the video you want to create... (e.g., 'A majestic mountain landscape with a flowing river and sunset in the background')"
          className="w-full rounded-lg border border-gray-300 dark:border-gray-700 bg-white dark:bg-gray-800 px-4 py-3 text-gray-900 dark:text-gray-100 focus:border-indigo-500 focus:ring-2 focus:ring-indigo-500/20 dark:focus:ring-indigo-500/30 transition-all duration-200"
          value={prompt}
          onChange={(e) => setPrompt(e.target.value)}
          required
        />
      </div>
      
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        {/* Style Selection */}
        <div className="relative">
          <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
            Video Style
          </label>
          <button
            type="button"
            className="w-full flex items-center justify-between rounded-lg border border-gray-300 dark:border-gray-700 bg-white dark:bg-gray-800 px-4 py-3 text-gray-900 dark:text-gray-100"
            onClick={() => setShowStyleDropdown(!showStyleDropdown)}
          >
            <div className="flex items-center">
              <Palette className="w-5 h-5 mr-2 text-indigo-600 dark:text-indigo-400" />
              <span>{getOptionById(styleOptions, style).name}</span>
            </div>
            <ChevronDown className="w-5 h-5 text-gray-500" />
          </button>
          
          {showStyleDropdown && (
            <div className="absolute z-10 mt-1 w-full rounded-md bg-white dark:bg-gray-800 shadow-lg border border-gray-200 dark:border-gray-700 max-h-60 overflow-auto">
              {styleOptions.map((option) => (
                <button
                  key={option.id}
                  type="button"
                  className={`w-full text-left px-4 py-3 flex items-center justify-between hover:bg-gray-50 dark:hover:bg-gray-700 ${
                    style === option.id ? 'bg-indigo-50 dark:bg-indigo-900/20 text-indigo-600 dark:text-indigo-400' : ''
                  }`}
                  onClick={() => {
                    setStyle(option.id);
                    setShowStyleDropdown(false);
                  }}
                >
                  <div>
                    <p className="font-medium">{option.name}</p>
                    <p className="text-sm text-gray-500 dark:text-gray-400">{option.description}</p>
                  </div>
                  {style === option.id && (
                    <CheckCircle2 className="w-5 h-5 text-indigo-600 dark:text-indigo-400" />
                  )}
                </button>
              ))}
            </div>
          )}
        </div>
        
        {/* Music Selection */}
        <div className="relative">
          <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
            Background Music
          </label>
          <button
            type="button"
            className="w-full flex items-center justify-between rounded-lg border border-gray-300 dark:border-gray-700 bg-white dark:bg-gray-800 px-4 py-3 text-gray-900 dark:text-gray-100"
            onClick={() => setShowMusicDropdown(!showMusicDropdown)}
          >
            <div className="flex items-center">
              <Music className="w-5 h-5 mr-2 text-indigo-600 dark:text-indigo-400" />
              <span>{getOptionById(musicOptions, music).name}</span>
            </div>
            <ChevronDown className="w-5 h-5 text-gray-500" />
          </button>
          
          {showMusicDropdown && (
            <div className="absolute z-10 mt-1 w-full rounded-md bg-white dark:bg-gray-800 shadow-lg border border-gray-200 dark:border-gray-700 max-h-60 overflow-auto">
              {musicOptions.map((option) => (
                <button
                  key={option.id}
                  type="button"
                  className={`w-full text-left px-4 py-3 flex items-center justify-between hover:bg-gray-50 dark:hover:bg-gray-700 ${
                    music === option.id ? 'bg-indigo-50 dark:bg-indigo-900/20 text-indigo-600 dark:text-indigo-400' : ''
                  }`}
                  onClick={() => {
                    setMusic(option.id);
                    setShowMusicDropdown(false);
                  }}
                >
                  <div>
                    <p className="font-medium">{option.name}</p>
                    <p className="text-sm text-gray-500 dark:text-gray-400">{option.description}</p>
                  </div>
                  {music === option.id && (
                    <CheckCircle2 className="w-5 h-5 text-indigo-600 dark:text-indigo-400" />
                  )}
                </button>
              ))}
            </div>
          )}
        </div>
        
        {/* Voice Selection */}
        <div className="relative">
          <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
            Voice Narration
          </label>
          <button
            type="button"
            className="w-full flex items-center justify-between rounded-lg border border-gray-300 dark:border-gray-700 bg-white dark:bg-gray-800 px-4 py-3 text-gray-900 dark:text-gray-100"
            onClick={() => setShowVoiceDropdown(!showVoiceDropdown)}
          >
            <div className="flex items-center">
              <Mic className="w-5 h-5 mr-2 text-indigo-600 dark:text-indigo-400" />
              <span>{getOptionById(voiceOptions, voice).name}</span>
            </div>
            <ChevronDown className="w-5 h-5 text-gray-500" />
          </button>
          
          {showVoiceDropdown && (
            <div className="absolute z-10 mt-1 w-full rounded-md bg-white dark:bg-gray-800 shadow-lg border border-gray-200 dark:border-gray-700 max-h-60 overflow-auto">
              {voiceOptions.map((option) => (
                <button
                  key={option.id}
                  type="button"
                  className={`w-full text-left px-4 py-3 flex items-center justify-between hover:bg-gray-50 dark:hover:bg-gray-700 ${
                    voice === option.id ? 'bg-indigo-50 dark:bg-indigo-900/20 text-indigo-600 dark:text-indigo-400' : ''
                  }`}
                  onClick={() => {
                    setVoice(option.id);
                    setShowVoiceDropdown(false);
                  }}
                >
                  <div>
                    <p className="font-medium">{option.name}</p>
                    <p className="text-sm text-gray-500 dark:text-gray-400">{option.description}</p>
                  </div>
                  {voice === option.id && (
                    <CheckCircle2 className="w-5 h-5 text-indigo-600 dark:text-indigo-400" />
                  )}
                </button>
              ))}
            </div>
          )}
        </div>
      </div>
      
      <button
        type="submit"
        disabled={isGenerating || !prompt.trim()}
        className={`w-full flex items-center justify-center space-x-2 rounded-lg px-6 py-4 text-base font-medium text-white transition-all
          ${isGenerating || !prompt.trim() 
            ? 'bg-indigo-400 cursor-not-allowed' 
            : 'bg-indigo-600 hover:bg-indigo-700 shadow-md hover:shadow-lg'
          }`}
      >
        <Sparkles className="w-5 h-5" />
        <span>{isGenerating ? 'Generating Video...' : 'Generate Video'}</span>
      </button>
    </form>
  );
};

export default PromptForm;