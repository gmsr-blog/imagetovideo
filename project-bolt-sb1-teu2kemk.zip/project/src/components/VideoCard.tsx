import React from 'react';
import { Play, Download, Trash2 } from 'lucide-react';
import { useVideo } from '../context/VideoContext';
import { Video } from '../types';

interface VideoCardProps {
  video: Video;
}

const VideoCard: React.FC<VideoCardProps> = ({ video }) => {
  const { deleteVideo } = useVideo();
  const [isHovering, setIsHovering] = React.useState(false);
  
  const handleDownload = (e: React.MouseEvent) => {
    e.stopPropagation();
    const a = document.createElement('a');
    a.href = video.url;
    a.download = `${video.title.replace(/\s+/g, '-').toLowerCase()}.mp4`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
  };
  
  const handleDelete = (e: React.MouseEvent) => {
    e.stopPropagation();
    if (window.confirm('Are you sure you want to delete this video?')) {
      deleteVideo(video.id);
    }
  };

  return (
    <div 
      className="group bg-white dark:bg-gray-800 rounded-lg shadow-md overflow-hidden transition-all duration-300 hover:shadow-xl"
      onMouseEnter={() => setIsHovering(true)}
      onMouseLeave={() => setIsHovering(false)}
    >
      <div className="relative aspect-video">
        <img 
          src={video.thumbnail} 
          alt={video.title} 
          className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-105"
        />
        
        <div className={`absolute inset-0 bg-black/50 flex items-center justify-center ${isHovering ? 'opacity-100' : 'opacity-0'} transition-opacity duration-300`}>
          <Play className="w-12 h-12 text-white" />
        </div>
        
        {/* Actions overlay */}
        <div className={`absolute bottom-0 left-0 right-0 p-3 bg-gradient-to-t from-black/70 to-transparent ${isHovering ? 'opacity-100' : 'opacity-0'} transition-opacity duration-300`}>
          <div className="flex justify-end space-x-2">
            <button
              onClick={handleDownload}
              className="p-2 rounded-full bg-white/20 hover:bg-white/30 text-white transition-colors"
              aria-label="Download video"
            >
              <Download className="w-4 h-4" />
            </button>
            <button
              onClick={handleDelete}
              className="p-2 rounded-full bg-red-500/20 hover:bg-red-500/30 text-white transition-colors"
              aria-label="Delete video"
            >
              <Trash2 className="w-4 h-4" />
            </button>
          </div>
        </div>
      </div>
      
      <div className="p-4">
        <h3 className="font-medium text-gray-900 dark:text-white line-clamp-1">{video.title}</h3>
        <p className="text-sm text-gray-500 dark:text-gray-400 mt-1">
          {new Date(video.createdAt).toLocaleDateString()}
        </p>
        <div className="flex flex-wrap gap-2 mt-2">
          <span className="px-2 py-1 text-xs rounded-full bg-indigo-100 dark:bg-indigo-900/30 text-indigo-700 dark:text-indigo-400">
            {video.style}
          </span>
          {video.music !== 'none' && (
            <span className="px-2 py-1 text-xs rounded-full bg-purple-100 dark:bg-purple-900/30 text-purple-700 dark:text-purple-400">
              {video.music}
            </span>
          )}
          {video.voice !== 'none' && (
            <span className="px-2 py-1 text-xs rounded-full bg-blue-100 dark:bg-blue-900/30 text-blue-700 dark:text-blue-400">
              {video.voice}
            </span>
          )}
        </div>
      </div>
    </div>
  );
};

export default VideoCard;