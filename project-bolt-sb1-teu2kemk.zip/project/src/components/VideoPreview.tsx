import React from 'react';
import { Play, Pause, Volume2, VolumeX, Download } from 'lucide-react';

interface VideoPreviewProps {
  videoUrl: string | null;
  thumbnail: string | null;
  isLoading: boolean;
  title: string;
}

const VideoPreview: React.FC<VideoPreviewProps> = ({ 
  videoUrl, 
  thumbnail, 
  isLoading, 
  title
}) => {
  const [isPlaying, setIsPlaying] = React.useState(false);
  const [isMuted, setIsMuted] = React.useState(false);
  const [progress, setProgress] = React.useState(0);
  const videoRef = React.useRef<HTMLVideoElement>(null);
  
  const togglePlay = () => {
    if (videoRef.current) {
      if (isPlaying) {
        videoRef.current.pause();
      } else {
        videoRef.current.play();
      }
      setIsPlaying(!isPlaying);
    }
  };
  
  const toggleMute = () => {
    if (videoRef.current) {
      videoRef.current.muted = !isMuted;
      setIsMuted(!isMuted);
    }
  };
  
  const handleTimeUpdate = () => {
    if (videoRef.current) {
      const currentProgress = (videoRef.current.currentTime / videoRef.current.duration) * 100;
      setProgress(currentProgress);
    }
  };
  
  const handleDownload = () => {
    if (videoUrl) {
      const a = document.createElement('a');
      a.href = videoUrl;
      a.download = `${title.replace(/\s+/g, '-').toLowerCase()}.mp4`;
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
    }
  };

  return (
    <div className="rounded-lg overflow-hidden bg-black shadow-xl">
      {isLoading ? (
        <div className="aspect-video flex items-center justify-center bg-gray-900">
          <div className="flex flex-col items-center">
            <div className="w-16 h-16 border-4 border-indigo-600 border-t-transparent rounded-full animate-spin"></div>
            <p className="mt-4 text-white font-medium">Generating your video...</p>
          </div>
        </div>
      ) : videoUrl ? (
        <div className="relative">
          <video 
            ref={videoRef}
            className="w-full aspect-video object-cover"
            poster={thumbnail || undefined}
            onTimeUpdate={handleTimeUpdate}
            onEnded={() => setIsPlaying(false)}
            src={videoUrl}
          />
          
          {/* Video Controls */}
          <div className="absolute bottom-0 left-0 right-0 bg-gradient-to-t from-black/70 to-transparent p-4 transform transition-transform duration-300 ease-in-out">
            <div className="flex flex-col space-y-2">
              <div className="w-full bg-gray-600/50 h-1 rounded-full overflow-hidden">
                <div 
                  className="h-full bg-indigo-600" 
                  style={{ width: `${progress}%` }}
                ></div>
              </div>
              
              <div className="flex justify-between items-center">
                <div className="flex space-x-4">
                  <button 
                    onClick={togglePlay}
                    className="text-white hover:text-indigo-400 transition-colors"
                    aria-label={isPlaying ? "Pause" : "Play"}
                  >
                    {isPlaying ? <Pause className="w-6 h-6" /> : <Play className="w-6 h-6" />}
                  </button>
                  
                  <button 
                    onClick={toggleMute}
                    className="text-white hover:text-indigo-400 transition-colors"
                    aria-label={isMuted ? "Unmute" : "Mute"}
                  >
                    {isMuted ? <VolumeX className="w-6 h-6" /> : <Volume2 className="w-6 h-6" />}
                  </button>
                </div>
                
                <button 
                  onClick={handleDownload}
                  className="text-white hover:text-indigo-400 transition-colors"
                  aria-label="Download video"
                >
                  <Download className="w-6 h-6" />
                </button>
              </div>
            </div>
          </div>
        </div>
      ) : thumbnail ? (
        <div className="relative aspect-video">
          <img 
            src={thumbnail} 
            alt={title} 
            className="w-full h-full object-cover"
          />
          <div className="absolute inset-0 flex items-center justify-center bg-black/30">
            <button 
              onClick={togglePlay}
              className="w-16 h-16 flex items-center justify-center rounded-full bg-indigo-600/80 hover:bg-indigo-700/80 transition-colors text-white"
              aria-label="Play"
            >
              <Play className="w-8 h-8" />
            </button>
          </div>
        </div>
      ) : (
        <div className="aspect-video flex items-center justify-center bg-gray-800 text-gray-400">
          <p>No video preview available</p>
        </div>
      )}
    </div>
  );
};

export default VideoPreview;