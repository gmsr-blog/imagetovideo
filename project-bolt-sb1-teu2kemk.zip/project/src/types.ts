export interface Video {
  id: string;
  title: string;
  prompt: string;
  url: string;
  thumbnail: string;
  style: string;
  music: string;
  voice: string;
  createdAt: string;
}